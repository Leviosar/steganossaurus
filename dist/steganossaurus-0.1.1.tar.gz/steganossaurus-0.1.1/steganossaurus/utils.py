def image_needed_size(byte_list, channels):
    return (byte_list * 4) / channels
